import random
import pygame

# Iniciación de Pygame
pygame.init()

# Pantalla - ventana
WIDTH, HEIGHT = 900, 600
FPS = 20
NEGRO = (0, 0, 0)
pantalla = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Lucha espacial")
icono = pygame.image.load("Images/fall.png")
pygame.display.set_icon(icono)

# Fondo del juego
fondo = pygame.image.load('Images/space.png')

#Musica del juego
pygame.mixer.music.load('Sonido/insect_factory.wav')
pygame.mixer.music.play(-1)

#Imagenes de las posiciones del personaje
quieto = pygame.image.load('Images/quieto.png')

camina_derecha = [pygame.image.load('Images/run_r.png'),
				pygame.image.load('Images/ruun_r.png')]

camina_izquierda = [pygame.image.load('Images/run_l.png'),
				pygame.image.load('Images/ruun_l.png')]

salta = [pygame.image.load('Images/salta_r.png'),
		pygame.image.load('Images/salta_l.png')]

#Imagenes del control de sonido
sonido_arriba = pygame.image.load('Sonido/Up.png')
sonido_abajo = pygame.image.load('Sonido/Down.png')
sonido_mute = pygame.image.load('Sonido/Mute.png')
sonido_maximo = pygame.image.load('Sonido/Maximo.png')

#Variables de posicion y desplazamiento del personaje
x = 0
px = 20
py = 500
ancho = 40
velocidad = 50

# Control de FPS
reloj = pygame.time.Clock()

# Variables salto
salto = False

# Contador de salto
cuenta_salto = 10

# Variables dirección
izquierda = False
derecha = False

# Pasos
cuenta_pasos = 0

# Movimiento
def recarga_pantalla():
	# Variables globales
	global cuenta_pasos
	global x
	# Fondo en movimiento
	x_relativa = x % fondo.get_rect().width
	pantalla.blit(fondo, (x_relativa - fondo.get_rect().width, 0))
	if x_relativa < WIDTH:
		pantalla.blit(fondo, (x_relativa, 0))
	x -= 5
	# Contador de pasos
	if cuenta_pasos + 1 >= 2:
		cuenta_pasos = 0
	# Movimiento a la izquierda
	if izquierda:
		pantalla.blit(camina_izquierda[cuenta_pasos // 1], (int(px), int(py)))
		cuenta_pasos += 1
	# Movimiento a la derecha
	elif derecha:
		pantalla.blit(camina_derecha[cuenta_pasos // 1], (int(px), int(py)))
		cuenta_pasos += 1
	#Salto
	elif salto + 1 >= 2:
		pantalla.blit(salta[cuenta_pasos // 1], (int(px), int(py)))
		cuenta_pasos += 1

	else:
		pantalla.blit(quieto, (int(px), int(py)))

ejecuta = True

#Los enemigos y obstaculos (POO)
#Enemigos
class Enemigos(pygame.sprite.Sprite):
	# Sprite del enemigo
	def __init__(self):
	# Heredamos el init de la clase Sprite de Pygame
		super().__init__()
		# Rectángulo (enemigos)
		self.img_aleatoria = random.randrange(1)
		self.image = pygame.image.load('Images/sierra.png').convert()
		# Rellenando el color de fondo de la imagen enemiga
		self.image.set_colorkey(NEGRO)
		#Rectangulo del sprite
		self.rect = self.image.get_rect()
		self.rect.x = random.randrange(WIDTH - self.rect.width) #Esos numeros son para que el enemigo no salga justo delante del jugador
		self.rect.y= - self.rect.width
		self.velocidad_x = random.randrange(1, 10)
	#Funcion de actualizacion de la clase Enemigos
	def update(self):
		self.rect.x += self.velocidad_x
		if self .rect.right > WIDTH:
			self.rect.y = random.randrange(WIDTH - self.rect.width)
			self.rect.x = - self.rect.width
		#Ancho
		self.velocidad_x = random.randrange(1, 10)
		self.rect.y += self.velocidad_x
#Clase obstaculo Minas
class Minas(pygame.sprite.Sprite):
	def __init__(self):
		# Heredamos el init de la clase Sprite de Pygame
		super().__init__()
		# Rectángulo (enemigos)
		self.img_aleatoria = random.randrange(3)
		if self.img_aleatoria == 0:
			self.image = pygame.transform.scale(pygame.image.load("Images/ball.png").convert(),(100,100))
			self.radius = 50
		if self.img_aleatoria == 1:
			self.image = pygame.transform.scale(pygame.image.load("Images/ball.png").convert(),(50,50))
			self.radius = 25
		if self.img_aleatoria == 2:
			self.image = pygame.transform.scale(pygame.image.load("Images/ball.png").convert(),(25,25))
			self.radius = 12
		self.image.set_colorkey(NEGRO)
		self.rect = self.image.get_rect()
		self.rect.x = random.randrange(WIDTH - self.rect.width)
		self.rect.y = random.randrange(HEIGHT - self.rect.height)
		self.velocidad_y = random.randrange(1, 10)

	def update(self):
		self.rect.y += self.velocidad_y
		if self .rect.top > HEIGHT:
			self.rect.x = random.randrange(WIDTH - self.rect.width)
			self.rect.y = - self.rect.width
		#Ancho
			self.velocidad_y = random.randrange(1, 50)

# Grupo de sprites e instanciaciones
sprites = pygame.sprite.Group()
enemigos = pygame.sprite.Group()
minas = pygame.sprite.Group()

#Enemigos
enemigo = Enemigos()
enemigos.add(enemigo)

#Instancia de enemigos
for x in range (random.randrange(5, 20) + 1):
	enemigo = Enemigos()
	enemigos.add(enemigo)

#Minas
mina = Minas()
minas.add(mina)

#Instancia de las minas
for x in range (5):
	mina = Minas()
	minas.add(mina)

# Bucle de acciones y controles
while ejecuta:
	# FPS
	reloj.tick(FPS)

	# Bucle del juego
	for event in pygame.event.get():
		if event.type == pygame.QUIT:
			ejecuta = False

	#Actualizaciones
	sprites.update()
	enemigos.update()
	minas.update()

	#Fondos
	sprites.draw(pantalla)
	enemigos.draw(pantalla)
	minas.draw(pantalla)

	# Opción tecla pulsada
	keys = pygame.key.get_pressed()

	# Tecla A - Moviemiento a la izquierda
	if keys[pygame.K_a] and px > velocidad:
		px -= velocidad
		izquierda = True
		derecha = False

	# Tecla D - Moviemiento a la derecha
	elif keys[pygame.K_d] and px < 900 - velocidad - ancho:
		px += velocidad
		izquierda = False
		derecha = True

	# Personaje quieto
	else:
		izquierda = False
		derecha = False
		cuenta_pasos = 0

	# Tecla W - Moviemiento hacia arriba
	if keys[pygame.K_w] and py > 20:
		py -= velocidad

	# Tecla S - Moviemiento hacia abajo
	if keys[pygame.K_s] and py < 510:
		py += velocidad
	# Tecla SPACE - Salto
	if not salto:
		if keys[pygame.K_SPACE]:
			salto = True
			izquierda = False
			derecha = False
			cuenta_pasos = 0
	else:
		if cuenta_salto >= -10:
			py -= (cuenta_salto * abs(cuenta_salto)) * 0.5
			cuenta_salto -= 1
		else:
			cuenta_salto = 10
			salto = False

	# Control del audio
	# Baja volumen
	if keys[pygame.K_LEFT] and pygame.mixer.music.get_volume() > 0.0:
		pygame.mixer.music.set_volume(pygame.mixer.music.get_volume() - 0.01)
		pantalla.blit(sonido_abajo, (700, 15))
	elif keys[pygame.K_LEFT] and pygame.mixer.music.get_volume() == 0.0:
		pantalla.blit(sonido_mute, (700, 15))

	# Sube volumen
	if keys[pygame.K_RIGHT] and pygame.mixer.music.get_volume() < 1.0:
		pygame.mixer.music.set_volume(pygame.mixer.music.get_volume() + 0.01)
		pantalla.blit(sonido_arriba, (700, 15))
	elif keys[pygame.K_RIGHT] and pygame.mixer.music.get_volume() == 1.0:
		pantalla.blit(sonido_maximo, (700, 15))

	# Desactivar sonido
	elif keys[pygame.K_DOWN]:
		pygame.mixer.music.set_volume(0.0)
		pantalla.blit(sonido_mute, (700, 15))

	# Reactivar sonido
	elif keys[pygame.K_UP]:
		pygame.mixer.music.set_volume(1.0)
		pantalla.blit(sonido_maximo, (700, 15))

	pygame.display.flip()
	#Llamada a la función de actualización de la ventana
	recarga_pantalla()

# Salida del juego
pygame.quit()